#!/usr/bin/env python3
"""
Meshtastic BLE-to-TCP Bridge

Connects to a Meshtastic device via Bluetooth Low Energy (BLE) and exposes
a TCP server that speaks the Meshtastic TCP framing protocol, allowing
MeshMonitor to connect to BLE-only devices.

Usage:
    python ble_tcp_bridge.py <BLE_ADDRESS> [--port 4403] [--verbose]

Example:
    python ble_tcp_bridge.py AA:BB:CC:DD:EE:FF --port 4403 --verbose

Requirements:
    pip install meshtastic bleak
"""

import asyncio
import socket
import struct
import logging
import argparse
import sys
from typing import List, Optional
from meshtastic.ble_interface import BLEInterface
from meshtastic import mesh_pb2

# TCP Protocol constants
START1 = 0x94
START2 = 0xC3
MAX_PACKET_SIZE = 512

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class MeshtasticBLEBridge:
    """
    Bridges Meshtastic BLE to TCP protocol for MeshMonitor compatibility.
    """

    def __init__(self, ble_address: str, tcp_port: int = 4403):
        self.ble_address = ble_address
        self.tcp_port = tcp_port
        self.ble_interface: Optional[BLEInterface] = None
        self.ble_client = None  # Direct BLE client reference

        # Meshtastic BLE characteristic UUIDs
        self.TORADIO_UUID = "f75c76d2-129e-4dad-a1dd-7866124401e7"  # Write to device
        self.tcp_clients: List[asyncio.StreamWriter] = []
        self.running = False

    async def start(self):
        """Start the BLE-TCP bridge."""
        logger.info(f"Starting BLE-TCP Bridge")
        logger.info(f"BLE Address: {self.ble_address}")
        logger.info(f"TCP Port: {self.tcp_port}")

        # Connect to BLE device
        await self.connect_ble()

        # Start TCP server
        await self.start_tcp_server()

    async def connect_ble(self):
        """Connect to Meshtastic device via BLE."""
        logger.info(f"Connecting to BLE device: {self.ble_address}")

        try:
            # The meshtastic library requires the address without colons for BLE
            # Convert AA:BB:CC:DD:EE:FF to AABBCCDDEEFF
            address_no_colons = self.ble_address.replace(':', '').replace('-', '')

            logger.debug(f"Formatted address: {address_no_colons}")

            # Create BLE interface with callback
            # Try with formatted address first
            try:
                self.ble_interface = BLEInterface(
                    address=address_no_colons,
                    noProto=False  # We want decoded protobufs
                )
            except:
                # Fall back to original address format
                self.ble_interface = BLEInterface(
                    address=self.ble_address,
                    noProto=False
                )

            # Set up message callback
            def on_receive(packet, interface):
                """Called when a packet is received from BLE."""
                asyncio.create_task(self.on_ble_packet(packet))

            self.ble_interface.showInfo = lambda *args: None  # Suppress info output

            # Wait for connection
            await asyncio.sleep(3)

            # Store direct reference to BleakClient for writing
            if hasattr(self.ble_interface, 'client'):
                self.ble_client = self.ble_interface.client
                logger.debug("Stored BleakClient reference")
            else:
                logger.warning("Could not get BleakClient reference")

            logger.info("✅ Connected to BLE device")

        except Exception as e:
            logger.error(f"❌ Failed to connect to BLE device: {e}")
            raise

    async def on_ble_packet(self, packet):
        """
        Handle incoming packet from BLE.
        Convert to TCP frame and broadcast to all TCP clients.
        """
        try:
            # Serialize protobuf
            protobuf_bytes = packet.SerializeToString()

            logger.debug(f"📥 BLE packet received: {len(protobuf_bytes)} bytes")

            # Create TCP frame
            tcp_frame = self.create_tcp_frame(protobuf_bytes)

            # Broadcast to all TCP clients
            await self.broadcast_to_tcp(tcp_frame)

        except Exception as e:
            logger.error(f"Error handling BLE packet: {e}")

    def create_tcp_frame(self, protobuf_bytes: bytes) -> bytes:
        """
        Create TCP frame from protobuf bytes.

        Frame format:
        [START1][START2][LENGTH_MSB][LENGTH_LSB][PROTOBUF_PAYLOAD]
        """
        length = len(protobuf_bytes)

        if length > MAX_PACKET_SIZE:
            raise ValueError(f"Packet too large: {length} > {MAX_PACKET_SIZE}")

        # Create 4-byte header
        header = struct.pack('>BBH', START1, START2, length)

        # Combine header and payload
        return header + protobuf_bytes

    async def broadcast_to_tcp(self, frame: bytes):
        """Broadcast frame to all connected TCP clients."""
        if not self.tcp_clients:
            logger.debug("No TCP clients connected, dropping packet")
            return

        logger.debug(f"📤 Broadcasting to {len(self.tcp_clients)} TCP client(s)")

        disconnected = []
        for writer in self.tcp_clients:
            try:
                writer.write(frame)
                await writer.drain()
            except Exception as e:
                logger.warning(f"Failed to send to TCP client: {e}")
                disconnected.append(writer)

        # Remove disconnected clients
        for writer in disconnected:
            self.tcp_clients.remove(writer)
            logger.info(f"TCP client disconnected ({len(self.tcp_clients)} remaining)")

    async def start_tcp_server(self):
        """Start TCP server to accept connections from MeshMonitor."""
        server = await asyncio.start_server(
            self.handle_tcp_client,
            '0.0.0.0',  # Listen on all interfaces
            self.tcp_port
        )

        addr = server.sockets[0].getsockname()
        logger.info(f"✅ TCP server listening on {addr[0]}:{addr[1]}")
        logger.info(f"MeshMonitor can now connect to <bridge-ip>:{self.tcp_port}")

        self.running = True

        async with server:
            await server.serve_forever()

    async def handle_tcp_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        """Handle a new TCP client connection."""
        addr = writer.get_extra_info('peername')
        logger.info(f"🔌 TCP client connected from {addr}")

        self.tcp_clients.append(writer)

        try:
            while self.running:
                # Read TCP frame header (4 bytes)
                header = await reader.readexactly(4)

                # Validate frame start
                if header[0] != START1 or header[1] != START2:
                    logger.warning(f"Invalid frame start: {header[0]:02x} {header[1]:02x}")
                    continue

                # Parse length (big-endian 16-bit)
                length = struct.unpack('>H', header[2:4])[0]

                logger.debug(f"📥 TCP frame received: {length} bytes")

                # Read protobuf payload
                protobuf_bytes = await reader.readexactly(length)

                # Parse protobuf
                try:
                    to_radio = mesh_pb2.ToRadio()
                    to_radio.ParseFromString(protobuf_bytes)

                    # Send via BLE
                    await self.send_to_ble(to_radio)

                except Exception as e:
                    logger.error(f"Failed to parse/send ToRadio packet: {e}")

        except asyncio.IncompleteReadError:
            logger.info(f"TCP client {addr} disconnected")
        except Exception as e:
            logger.error(f"Error handling TCP client: {e}")
        finally:
            if writer in self.tcp_clients:
                self.tcp_clients.remove(writer)
            writer.close()
            await writer.wait_closed()
            logger.info(f"TCP client {addr} closed ({len(self.tcp_clients)} remaining)")

    async def send_to_ble(self, packet: mesh_pb2.ToRadio):
        """Send ToRadio packet to BLE device."""
        if not self.ble_client:
            raise RuntimeError("BLE client not connected")

        try:
            logger.debug(f"📤 Sending packet to BLE")

            # Serialize the protobuf to bytes
            packet_bytes = packet.SerializeToString()

            # Write directly to the ToRadio characteristic using BleakClient
            await self.ble_client.write_gatt_char(self.TORADIO_UUID, packet_bytes)

            logger.debug(f"✅ Sent {len(packet_bytes)} bytes to BLE")

        except Exception as e:
            logger.error(f"Failed to send to BLE: {e}")
            raise

    def stop(self):
        """Stop the bridge."""
        logger.info("Stopping BLE-TCP bridge...")
        self.running = False

        if self.ble_interface:
            try:
                self.ble_interface.close()
            except:
                pass


async def scan_for_meshtastic():
    """Scan for nearby Meshtastic BLE devices."""
    logger.info("Scanning for Meshtastic devices...")

    try:
        from bleak import BleakScanner

        # Meshtastic service UUID
        MESHTASTIC_SERVICE_UUID = "6ba1b218-15a8-461f-9fa8-5dcae273eafd"

        devices = await BleakScanner.discover(timeout=5.0)

        meshtastic_devices = []
        for device in devices:
            # Check if device advertises Meshtastic service
            if device.name and ("meshtastic" in device.name.lower()):
                meshtastic_devices.append(device)
                logger.info(f"  Found: {device.name} ({device.address})")

        if not meshtastic_devices:
            logger.warning("No Meshtastic devices found")

        return meshtastic_devices

    except Exception as e:
        logger.error(f"Scan failed: {e}")
        return []


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Meshtastic BLE-to-TCP Bridge for MeshMonitor",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Connect to specific device
  %(prog)s AA:BB:CC:DD:EE:FF

  # Use custom TCP port
  %(prog)s AA:BB:CC:DD:EE:FF --port 14403

  # Scan for devices
  %(prog)s --scan

  # Verbose logging
  %(prog)s AA:BB:CC:DD:EE:FF --verbose
        """
    )

    parser.add_argument(
        'ble_address',
        nargs='?',
        help='BLE MAC address of Meshtastic device (e.g., AA:BB:CC:DD:EE:FF)'
    )
    parser.add_argument(
        '--port',
        type=int,
        default=4403,
        help='TCP port to listen on (default: 4403)'
    )
    parser.add_argument(
        '--scan',
        action='store_true',
        help='Scan for Meshtastic BLE devices and exit'
    )
    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Enable verbose logging'
    )

    args = parser.parse_args()

    # Set logging level
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Handle scan mode
    if args.scan:
        asyncio.run(scan_for_meshtastic())
        return

    # Validate BLE address
    if not args.ble_address:
        parser.error("BLE address is required (use --scan to find devices)")

    # Create and run bridge
    bridge = MeshtasticBLEBridge(args.ble_address, args.port)

    try:
        asyncio.run(bridge.start())
    except KeyboardInterrupt:
        logger.info("\n🛑 Interrupted by user")
        bridge.stop()
    except Exception as e:
        logger.error(f"❌ Bridge failed: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
